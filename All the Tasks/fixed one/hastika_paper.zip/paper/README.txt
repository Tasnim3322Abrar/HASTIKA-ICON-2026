HASTIKA @ ICON-2026 working note (ACL template)

FILES
  main.tex          paper source
  references.bib    bibliography (includes the mandatory HASTIKA dataset citation)
  acl.sty, acl_natbib.bst   official ACL style files
  figures/          all figures used in the paper (PDF)
  main.pdf          compiled preview

HOW TO COMPILE (Overleaf)
  Upload the whole folder (or this zip) as a new project. Main file = main.tex.
  Compiler: pdfLaTeX.  Bibliography is run automatically.

BEFORE SUBMITTING - TODO
  1. main.tex, \author{...}: replace "Your Affiliation / City, Country / email".
  2. Check the two leaderboard columns (Table 5 / abstract): macro-F1 and accuracy are assumed.
  3. Check every entry in references.bib once.
  4. For an anonymous version change \usepackage[preprint]{acl} to [review].
